
#!/usr/bin/env bash
set -euo pipefail
# Usage: bash /oraprd/oracle_patching_script/04_run_datapatch.sh [state_file]

STATE_FILE="${1:-/oraprd/oracle_patching_script/patch_state.env}"
source "$STATE_FILE"
source /oraprd/oracle_patching_script/scripts/common.sh || true  # continue even if older common.sh

init_logging_dirs
log_message "=== Datapatch Phase: starting on host $(hostname) ==="

require_var ORACLE_HOME
require_var LOGDIR
require_cmd tee awk grep sqlplus

OPATCH_DATAPATCH_BIN="$ORACLE_HOME/OPatch/datapatch"
if [[ ! -x "$OPATCH_DATAPATCH_BIN" ]]; then
  log_message "datapatch binary not found at $OPATCH_DATAPATCH_BIN"; exit 1
fi

# Fallback: define sql_one if common.sh didn't provide it
if ! type sql_one >/dev/null 2>&1; then
  sql_one() {
    local sql="$1"
    "$ORACLE_HOME/bin/sqlplus" -s / as sysdba <<SQL | tr -d $'' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'
set heading off feedback off pages 0 verify off
${sql}
exit
SQL
  }
fi

# Discover SIDs via PMON (robust parser)
log_message "Discovering started instances via PMON"
mapfile -t sids < <(
  ps -eo args | awk 'match($0,/ora_pmon_([A-Za-z0-9_]+)/,m){ print m[1] }' | sort -u
)
# Defensive filter: allow only SIDs that match expected pattern
sids=( $(printf '%s
' "${sids[@]}" | awk '/^[A-Za-z0-9_]+$/') )

if (( ${#sids[@]} == 0 )); then
  log_message "No running instances discovered via PMON. Ensure DBs are started before datapatch."; exit 1
fi

for ORACLE_SID in "${sids[@]}"; do
  [[ -z "$ORACLE_SID" ]] && continue
  export ORACLE_SID
  log_message "datapatch: $ORACLE_SID"

  # Determine role and CDB
  db_role="$(sql_one 'select database_role from v$database')"
  cdb_flag="$(sql_one 'select cdb from v$database')"
  [[ -z "$db_role" ]] && db_role="UNKNOWN"
  [[ -z "$cdb_flag" ]] && cdb_flag="NO"

  # Skip standby
  if [[ "$db_role" =~ STANDBY ]]; then
    log_message "Skipping $ORACLE_SID (role=$db_role). datapatch should run on PRIMARY."
    continue
  fi

  # Ensure DB open read write
  open_mode="$(sql_one 'select open_mode from v$database')"
  if [[ "$open_mode" != "READ WRITE" ]]; then
    log_message "Instance $ORACLE_SID not open READ WRITE (open_mode='$open_mode'). Attempting STARTUP."
    "$ORACLE_HOME/bin/sqlplus" -s / as sysdba >>"$MASTER_LOG" 2>&1 <<'EOF'
startup;
exit;
EOF
    sleep 2
    open_mode="$(sql_one 'select open_mode from v$database')"
    log_message "Post-start open_mode for $ORACLE_SID: $open_mode"
  fi

  # If CDB, open all PDBs (best effort)
  if [[ "$cdb_flag" == "YES" ]]; then
    log_message "CDB detected. Opening all PDBs (best effort)."
    "$ORACLE_HOME/bin/sqlplus" -s / as sysdba >>"$MASTER_LOG" 2>&1 <<'EOF'
alter pluggable database all open;
exit;
EOF
  fi

  # Execute datapatch
  if "$OPATCH_DATAPATCH_BIN" -verbose >>"$MASTER_LOG" 2>&1; then
    log_message "datapatch completed for $ORACLE_SID"
    "$OPATCH_DATAPATCH_BIN" -sqlpatch_status >>"$MASTER_LOG" 2>&1 || true
  else
    rc=$?
    log_message "datapatch returned non-zero (rc=$rc) for $ORACLE_SID"
  fi

done

log_message "=== Datapatch Phase: completed ==="
