
#!/usr/bin/env bash
# Debug mode: export ORCHESTRATOR_DEBUG=1
if [[ "${ORCHESTRATOR_DEBUG:-0}" == "1" ]]; then
  set -xeuo pipefail
else
  set -euo pipefail
fi

# Args: -s|--state <file>  -p|--patch-id <id>
STATE_FILE=""
PATCH_ID_ARG=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    -s|--state)     STATE_FILE="$2"; shift 2 ;;
    -p|--patch-id)  PATCH_ID_ARG="$2"; shift 2 ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

STATE_FILE="${STATE_FILE:-/oraprd/oracle_patching_script/patch_state.env}"
source "$STATE_FILE"
source /oraprd/oracle_patching_script/scripts/common.sh || { echo "Failed to source common.sh"; exit 1; }
init_logging_dirs

[[ -n "$PATCH_ID_ARG" ]] && export PATCH_ID="$PATCH_ID_ARG"

log_message "=== Orchestration started ==="
require_var ORACLE_HOME
require_var LOGDIR
require_cmd tee awk grep sed find env bash head od chmod

# Phase runner
FAIL_COUNT=0
run_phase() {
  local phase_name="$1"; shift
  local phase_script="$1"; shift
  local phase_state="${1:-$STATE_FILE}"

  [[ ! -x "$phase_script" ]] && log_message "INFO: ${phase_name}: ${phase_script} is not executable; invoking via 'bash' anyway."

  log_message "=== ${phase_name}: starting ==="
  local start_ts; start_ts=$(date +%s)
  bash "$phase_script" "$phase_state"
  local rc=$?
  local dur=$(( $(date +%s) - start_ts ))

  if [[ $rc -ne 0 ]]; then
    log_message "ERROR: ${phase_name} failed with rc=${rc} (script: ${phase_script}). See ${MASTER_LOG}"
    FAIL_COUNT=$(( FAIL_COUNT + 1 ))
  else
    log_message "=== ${phase_name}: completed in ${dur}s ==="
  fi
  return $rc
}

# Run phases (continue regardless; tally failures)
run_phase "Stop Phase"      "/oraprd/oracle_patching_script/01_stop_db_services.sh"      "$STATE_FILE" || true
run_phase "Backup+Patch"    "/oraprd/oracle_patching_script/02_backup_and_patch.sh"      "$STATE_FILE" || true
run_phase "Start Phase"     "/oraprd/oracle_patching_script/03_start_db_services.sh"      "$STATE_FILE" || true
run_phase "Datapatch Phase" "/oraprd/oracle_patching_script/04_run_datapatch.sh"         "$STATE_FILE" || true

# Final summary
if [[ $FAIL_COUNT -gt 0 ]]; then
  log_message "=== Orchestration completed with ${FAIL_COUNT} error(s) ==="
  exit 1
else
  log_message "=== Orchestration completed successfully ==="
  exit 0
fi
